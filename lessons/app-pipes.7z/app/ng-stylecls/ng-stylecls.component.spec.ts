import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgStyleclsComponent } from './ng-stylecls.component';

describe('NgStyleclsComponent', () => {
  let component: NgStyleclsComponent;
  let fixture: ComponentFixture<NgStyleclsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgStyleclsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgStyleclsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
