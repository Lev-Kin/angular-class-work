import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'app-http';

  data!: Object;
  loading = false; // индикатор загрузки
  httpOptions = {
    headers: new HttpHeaders().set('Content-Type', 'application/json'),
  };

  constructor(private http: HttpClient) {}

  getData(): void {
    this.loading = true;
    this.http.get(`http://localhost:3000/products`).subscribe((data) => {
      this.data = data;
      this.loading = false;
    });
  }

  addData(): void {
    this.http
      .post(`http://localhost:3000/products`, {
        id: 10,
        name: 'smartphone',
        price: 1000,
      })
      .subscribe((data) => {
        this.data = data;
      });
  }

  deleteData(): void {
    this.http.delete(`/10`, this.httpOptions).subscribe((data) => {
      this.data = data;
    });
  }
}
