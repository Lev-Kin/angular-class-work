import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-for',
  templateUrl: './ng-for.component.html',
  styleUrls: ['./ng-for.component.css'],
})
export class NgForComponent implements OnInit {
  products = ['milck', 'bread', 'butter', 'meat', 'fish', 'berries'];

  constructor() {}

  ngOnInit(): void {}

  sortedList(): string[] {
    let list = this.products.slice();
    return list.sort();
  }
}
