import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-stylecls',
  templateUrl: './ng-stylecls.component.html',
  styleUrls: ['./ng-stylecls.component.css']
})
export class NgStyleclsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
