import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  src =
    'https://pic.belkagomel.by/2021/08/gotovte-voprosy-ut-pryamye-linii-1024x683.jpg';

  constructor() {}

  ngOnInit(): void {}
}
