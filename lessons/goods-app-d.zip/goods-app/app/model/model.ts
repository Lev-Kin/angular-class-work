export interface Product {
  id?: number;
  name?: string;
  category?: string;
  description?: string;
  img?: string;
  price?: number;
}
