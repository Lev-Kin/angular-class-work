import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'interaction';

  products = [
    {
      name: 'PC',
      processor: 'I7',
      RAM: '64Gb',
    },
    {
      name: 'tablet',
      processor: 'I3',
      RAM: '8Gb',
    },
  ];

  childData!: string;

  getData(value: string) {
    this.childData = value;
  }
}
