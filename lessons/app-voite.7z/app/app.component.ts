import { Component } from '@angular/core';
import { IArticle } from './model/model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'app-voite';

  list: IArticle[] = [
    { title: 'angular', url: 'https://angular.io/', voitePoints: 5 },
    {
      title: 'javascript',
      url: 'https://learn.javascript.ru/',
      voitePoints: 3,
    },
  ];

  addArticle(obj: IArticle): void {
    this.list.push(obj);
  }

  sortedList(): IArticle[] {
    let arr = [...this.list];
    arr.sort((a: IArticle, b: IArticle) => {
      return b.voitePoints! - a.voitePoints!;
    });
    return arr;
  }
}
