import { Component, OnInit, Input } from '@angular/core';
import { IArticle } from '../model/model';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css'],
})
export class ArticleComponent implements OnInit {
  @Input() item!: IArticle;

  constructor() {}

  ngOnInit(): void {}

  voiteUp(): void {
    this.item.voitePoints = this.item.voitePoints! + 1;
  }

  voiteDown(): void {
    this.item.voitePoints!--;
    if (this.item.voitePoints! < 0) {
      this.item.voitePoints = 0;
    }
  }
}
