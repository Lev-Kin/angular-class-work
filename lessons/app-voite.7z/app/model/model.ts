export interface IArticle {
  title?: string;
  url?: string;
  voitePoints?: number;
}
